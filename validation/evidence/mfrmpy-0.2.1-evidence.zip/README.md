# mfrmpy 0.2.1 の疎な評定と外部エンジン比較

2026-11-20。60人、4課題、3評価者、0～3点の共通段階尺度。R1, R2, R3 の厳しさの真値は −0.6, 0, 0.6 logit。課題難度は −0.75, −0.25, 0.25, 0.75、閾値は −0.9, 0, 0.9。各反復で能力を独立に N(0,1) から生成し、能力・課題・評価者・共通閾値を用いる加法RSMから評定を生成した。能力を所与として各評定は独立。得点と独立に割当を間引き、同じ反復の完全交差720評定と、各240評定で二重採点者が60人・6人の2設計を作った。各デザイン30反復。data に解析した合成データをすべて収録した。各評価者対の共有人数は疎な2設計でそれぞれ20人と2人。

- coverage.csv は固定SD MMLの既定設定（GH31）による R3 − R1 の95%指定区間。分母は全30反復と実際に区間を返した反復を区別する。summarize.py の二項信頼区間は、返却時の被覆割合に対する両側Clopper–Pearson 95%区間。1.2 は真の対比。
- anchors.csv は二重採点6人、固定なし・R1/R2を既知の真値に固定・R1のみ +0.4 ずらして固定した3条件。分母は各30反復。error は推定した R3 − R1 から真値1.2を引いた値。固定値自体を別標本から推定する設計は含まない。
- bias-and-joint.csv は各設計の第1反復で、評価者×課題の条件付きBiasと同時推定された交互作用をそれぞれ呼び出した表示結果。joint の集計はセル表と要約表を含み、CIEligible 列はセル表を対象とする。個人の集団属性を持たないのでDFFの検出力は評価していない。
- engine-comparison.csv は各設計の第1反復のRSM。校正の原点をそろえるため、Pythonはnoncenter_facet=Item、ConQuestはlconstraints=casesと分散1の固定、TAMは項目を自由・評価者と閾値を各和ゼロとするAを使用。3実装とも母集団はN(0,1)。PythonはGH81と厳しい収束基準、TAM 4.3.25とConQuest 5.47.5は−8～8の161点等間隔求積。共通の8自由座標（課題4・評価者2・段階2）の最大絶対差と対数尤度の絶対差を算出。ConQuestではCSVのパラメータと保存devianceの表示桁の丸めを含む。ここでの設定は coverage.csv の既定設定とは異なる。

- joint6 は二重採点6人の第1反復に課題×評価者の交互作用を加えた別の同時推定。ConQuestの課題内で和がゼロの評価者効果を難度から予測子に向きをそろえ、行・列の平均を除いてPythonの両周辺和ゼロの12セルと比較した。ConQuestには一部の組合せで観測された段階数が違う旨の警告があり、両方で0～3点の共通段階を仮定している。外部比較は点推定と対数尤度のみ。各実行の終了と警告抜粋は termination.txt にある。

展開したディレクトリを作業場所にして実行する。Python 3.12、mfrmpy 0.2.1（numpy, pandas, scipy）、RのTAM 4.3.25を使用。ConQuestを再実行する場合は自分のライセンス済み実行ファイルを指定する。各実行は一時ディレクトリで行い、収束と正常終了を確認してから出力を更新する。配布物にはConQuest本体・ライセンス・個人データを含めていない。

```sh
python coverage.py
python anchors-bias.py
python compare.py
python joint6-python.py
Rscript --vanilla tam.R > tam.log
python native.py /Applications/ConQuest/ConQuest
python summarize.py
python compare-joint.py
```

検証済みの出力を同梱しているため、集計だけなら最後の2コマンドで再現できる。
