from pathlib import Path
import csv
import mfrmpy
import pandas as pd
import numpy as np
root=Path('data')
settings=dict(person='Person',facets=['Item','Rater'],score='Score',rating_min=0,rating_max=3,method='MML')
with open('anchors.csv','w',newline='') as f:
    writer=csv.writer(f); writer.writerow(['rep','fixed_R1','fixed_R2','R3_minus_R1','error'])
    for path in sorted((root/'shared6').glob('rep_*/ratings.csv')):
        data=pd.read_csv(path)
        for a1 in (None,-.6,-.2):
            anchors=[] if a1 is None else [dict(Facet='Rater',Level='R1',Anchor=a1),dict(Facet='Rater',Level='R2',Anchor=0.)]
            a=mfrmpy.analyze(data,**settings,anchors=anchors)
            result=a['result']; assert result['summary'].Converged.iloc[0]
            rat=result['facets']['others'].query("Facet == 'Rater'").set_index('Level').Estimate
            if a1 is not None: assert rat.R1==a1 and rat.R2==0.
            contrast=rat.R3-rat.R1
            writer.writerow([path.parent.name,a1,0. if a1 is not None else None,contrast,contrast-1.2])
        f.flush()
with open('bias-and-joint.csv','w',newline='') as f:
    writer=csv.writer(f); writer.writerow(['design','kind','status','n','detail'])
    for design in ('complete','shared60','shared6'):
        data=pd.read_csv(root/design/'rep_01'/'ratings.csv')
        pair=dict(facet_a='Rater',facet_b='Item')
        a=mfrmpy.analyze(data,**settings,bias_requests=[pair],joint_settings=pair)
        for name in ('bias','joint'):
            for title,tab,note in mfrmpy.tables(a,name):
                for col in ('Use','CIEligible','Reason','StatusReason'):
                    if col in tab:
                        for key,n in tab[col].value_counts(dropna=False).items():
                            writer.writerow([design,name,col,n,str(key)])
                if name=='joint':
                    writer.writerow([design,name,a['joint_analysis']['status'],len(tab),a['joint_analysis'].get('reason','')])
