from pathlib import Path
import numpy as np
import pandas as pd
p=Path('joint6')
q=pd.read_csv(p/'parameters.csv')
cells={}
for label,val in zip(q.Label,q.Estimate):
    parts=label.split()
    if len(parts)==4 and parts[0]=='item' and parts[2]=='rater':
        cells[(parts[1],parts[3])]=val
x=pd.Series(cells).unstack()
assert x.shape==(4,2) and list(x.columns)==['R1','R2']
x['R3']=-x[['R1','R2']].sum(axis=1)
eta=-x
pure=eta.sub(eta.mean(axis=1),axis=0).sub(eta.mean(axis=0),axis=1)+eta.to_numpy().mean()
py=pd.read_csv(p/'python-cells.csv').pivot(index='LevelA',columns='LevelB',values='Estimate')
assert py.index.tolist()==pure.index.tolist() and py.columns.tolist()==pure.columns.tolist()
diff=float(np.max(np.abs(py.to_numpy()-pure.to_numpy())))
nll=float((p/'python-nll.txt').read_text())
cq_nll=float((p/'history.txt').read_text().strip().splitlines()[-1].split()[2])/2
print("12 interaction cell deviations on common eta scale, max abs difference",diff,"absolute loglik difference",abs(cq_nll-nll))
