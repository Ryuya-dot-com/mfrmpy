from pathlib import Path
import json
import numpy as np
import pandas as pd
import mfrmpy
root=Path('data')
for design in ('complete','shared60','shared6'):
    a=mfrmpy.analyze(pd.read_csv(root/design/'rep_01'/'ratings.csv'),person='Person',facets=['Item','Rater'],score='Score',rating_min=0,rating_max=3,noncenter_facet='Item',model='RSM',method='MML',quad_points=81,reltol=1e-12,maxit=1200)
    res=a['result']; assert res['summary'].Converged.iloc[0]
    f=res['facets']['others'].set_index('Level').Estimate
    values={**dict(f),**{'S'+str(j):float(v) for j,v in enumerate(res['params']['steps'],1)}}
    Path('python-'+design+'.json').write_text(json.dumps({'parameters':values,'loglik':float(res['summary'].LogLik.iloc[0])},indent=2))
