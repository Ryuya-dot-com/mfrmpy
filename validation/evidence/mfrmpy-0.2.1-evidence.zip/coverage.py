from pathlib import Path
import csv
import pandas as pd
import mfrmpy
assert mfrmpy.__version__ == '0.2.1'
root=Path('data')
with open('coverage.csv','w',newline='') as f:
    writer=csv.writer(f)
    writer.writerow(['design','rep','returned','lower','upper','covers_1.2','reason'])
    for design in ('complete','shared60','shared6'):
        for path in sorted((root/design).glob('rep_*/ratings.csv')):
            rep=int(path.parent.name.split('_')[1])
            a=mfrmpy.analyze(pd.read_csv(path),person='Person',facets=['Item','Rater'],score='Score',rating_min=0,rating_max=3,model='RSM',method='MML',
                             interval_requests=[dict(facet='Rater',difference=['R3','R1'],level=.95)])
            rec=a['interval_analyses'][0]
            if rec['status']=='computed':
                row,=[r for r in rec['record']['table'] if r['Kind']=='difference']
                ok=row['CIEligible']; lo=row['Lower']; hi=row['Upper']
                writer.writerow([design,rep,ok,lo,hi,lo<=1.2<=hi if ok else None,row['Reason']])
            else:
                writer.writerow([design,rep,False,None,None,None,rec['reason']])
            f.flush()
