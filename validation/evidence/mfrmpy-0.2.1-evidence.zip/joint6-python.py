from pathlib import Path
import json
import pandas as pd
import mfrmpy
d=Path("joint6")
a=mfrmpy.analyze(pd.read_csv(Path("data/shared6/rep_01/ratings.csv")), person='Person',facets=['Item','Rater'],score='Score',rating_min=0,rating_max=3,method='MML',noncenter_facet='Item',quad_points=81,reltol=1e-12,maxit=1200,joint_settings=dict(facet_a='Item',facet_b='Rater'))
j=a['joint_analysis']
if j['status']!='computed': raise ValueError(j)
r=j['record']
rows=pd.DataFrame(r['table'])
rows.to_csv(d/'python-cells.csv',index=False)
(d/'python-nll.txt').write_text(repr(r['calculations'][0]['raw_nll']))
