"""Re-run each native calibration in a new directory and retain only validated outputs."""
from pathlib import Path
from shutil import copyfile
from tempfile import TemporaryDirectory
import subprocess
import sys

binary=str(Path(sys.argv[1]).resolve())
for design in ('complete','shared60','shared6','joint6'):
    folder=Path(design)
    with TemporaryDirectory() as tmp:
        stage=Path(tmp)
        for name in ('model.cqc','covariance.txt'):
            copyfile(folder/name,stage/name)
        copyfile(Path('data')/('shared6' if design=='joint6' else design)/'rep_01'/'ratings.csv',stage/'ratings.csv')
        with (stage/'model.cqc').open() as cmds, (stage/'console.log').open('w') as log:
            subprocess.run([binary],cwd=stage,stdin=cmds,stdout=log,stderr=subprocess.STDOUT,check=True)
        text=(stage/'console.log').read_text(errors='replace')
        messages=['Deviance change is less than convergence criterion','End of Program']
        if not all(message in text for message in messages):
            raise RuntimeError(f'{design}: ConQuest did not confirm convergence and normal termination')
        for name in ('parameters.csv','history.txt','var.txt'):
            copyfile(stage/name,folder/name)
        (folder/'termination.txt').write_text('\n'.join(messages)+'\n')
