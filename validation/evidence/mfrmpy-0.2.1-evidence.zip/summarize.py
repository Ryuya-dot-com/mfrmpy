from pathlib import Path
import csv,re,json
from scipy.stats import binomtest
import pandas as pd
import numpy as np
base = Path('.')
rows=[]
tam_ll=dict(re.findall(r'^(complete|shared60|shared6).*loglik ([-\d.]+)',Path('tam.log').read_text(),re.M))
for design in ('complete','shared60','shared6'):
 out=base/design
 py=json.loads((base/f'python-{design}.json').read_text())
 native=pd.read_csv(out/'parameters.csv')
 params={}
 for label,v in zip(native.Label,native.Estimate):
    facet,level=label.split(); key='S'+level if facet=='category' else level
    assert key not in params
    params[key]=v
 assert set(params)=={'I1','I2','I3','I4','R1','R2','S1','S2'}
 assert 'Deviance change is less than convergence criterion' in (out/'termination.txt').read_text(errors='replace')
 cq_ll=-float((out/'history.txt').read_text().strip().splitlines()[-1].split()[2])/2
 tam=pd.read_csv(f'tam-{design}.csv').set_index('name').est.to_dict()
 assert set(tam)==set(params)
 rows.append(dict(design=design,free=len(params),cq_max_abs=max(abs(v-py['parameters'][n]) for n,v in params.items()),cq_abs_loglik=abs(cq_ll-py['loglik']),tam_max_abs=max(abs(v-py['parameters'][n]) for n,v in tam.items()),tam_abs_loglik=abs(float(tam_ll[design])-py['loglik'])))
checks=pd.DataFrame(rows);checks.to_csv('engine-comparison.csv',index=False);print(checks.to_string(index=False))
c=pd.read_csv('coverage.csv')
for name,tbl in c.groupby('design'):
 ret=tbl[tbl.returned]
 n=len(ret); h=sum(ret['covers_1.2']==True); ci=binomtest(h,n).proportion_ci() if n else None
 print(name,len(tbl),n,h,ci)

anchors=pd.read_csv('anchors.csv')
for level,t in anchors.groupby('fixed_R1',dropna=False):
    print('anchor R1',level,'n',len(t),'mean error',t.error.mean(),'RMSE',np.sqrt((t.error**2).mean()))
