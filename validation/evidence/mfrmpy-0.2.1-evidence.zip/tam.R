suppressPackageStartupMessages(library(TAM))
root <- 'data'
for (design in c("complete","shared60","shared6")) {
  d <- read.csv(file.path(root,design,"rep_01","ratings.csv"))
  items <- sort(unique(d$Item)); raters <- sort(unique(d$Rater))
  cells <- expand.grid(Item=items,Rater=raters,stringsAsFactors=FALSE)
  id <- function(x) paste(x$Item,x$Rater)
  person <- sort(unique(d$Person))
  y <- matrix(NA_real_,length(person),nrow(cells),dimnames=list(person,id(cells)))
  y[cbind(match(d$Person,person),match(id(d),id(cells)))] <- d$Score
  pars <- c(items,raters[1:2],"S1","S2")
  A <- array(0,c(ncol(y),4,8),dimnames=list(id(cells),as.character(0:3),pars))
  B <- array(0,c(ncol(y),4,1),dimnames=list(id(cells),as.character(0:3),"Ability"))
  C <- rbind(diag(2),c(-1,-1))
  for (j in seq_len(nrow(cells))) for (k in 1:3) {
    A[j,k+1,match(cells$Item[j],items)] <- -k
    A[j,k+1,5:6] <- -k*C[match(cells$Rater[j],raters),]
    A[j,k+1,7:8] <- -colSums(C[seq_len(k),,drop=FALSE])
    B[j,k+1,1] <- k
  }
  fit <- tam.mml(resp=y,A=A,B=B,variance.fixed=matrix(c(1,1,1),1,3),beta.fixed=matrix(c(1,1,0),1,3),verbose=FALSE,
                 control=list(nodes=seq(-8,8,length.out=161),conv=1e-10,convD=1e-10,convM=1e-10,maxiter=2000))
  stopifnot(nrow(fit$xsi)==8, fit$iter<2000)
  write.csv(data.frame(name=pars,est=as.numeric(fit$xsi$xsi)),paste0('tam-',design,'.csv'),row.names=FALSE)
  cat(design,'obs',sum(!is.na(y)),'people',length(person),'iter',fit$iter,'loglik',sprintf('%.12f',-fit$deviance/2),'\n')
}
